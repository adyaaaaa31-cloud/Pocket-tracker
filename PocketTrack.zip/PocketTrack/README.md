# PocketTrack 💰

A simple, offline pocket-money and expense tracker for Indian college students.
Kotlin · Jetpack Compose · Material 3 · Room · ₹ (Indian digit grouping)

## Features
- **Home** – money received, total expenses, remaining balance, today's spending, recent transactions
- **Add** – income or expense, amount (validated), description, category, date picker
- **History** – filter All / Income / Expenses, sort by date, delete with confirmation
- **Goal** – set a savings target; progress = remaining balance ÷ target
- **Report** – pick a month; income, expenses, net, and spending by category
- Light + dark theme (follows system), fully offline, no sample data

## Project structure
```
app/src/main/java/com/pockettrack/app/
  MainActivity.kt
  data/   Models.kt  Database.kt  MainViewModel.kt
  ui/     PocketTrackRoot.kt  DashboardScreen.kt  AddTransactionScreen.kt
          HistoryScreen.kt  GoalScreen.kt  ReportScreen.kt  Components.kt
  ui/theme/Theme.kt
  util/Format.kt
```

## Build in Android Studio
1. Install Android Studio (Koala or newer; JDK 17 is bundled).
2. **File → Open** and select the `PocketTrack` folder. Wait for Gradle sync.
   (If it complains about the wrapper, run `gradle wrapper --gradle-version 8.7` once.)
3. Press ▶ Run on an emulator or a USB-debugging phone.

## Export an APK
- **Quick (debug) APK for sharing:** Build → Build Bundle(s) / APK(s) → Build APK(s).
  File: `app/build/outputs/apk/debug/app-debug.apk`.
- **Signed release APK:** Build → Generate Signed Bundle / APK → APK → create a keystore → choose *release*.
  Keep the keystore safe; you need it for every update.

## GitHub
```
git init
git add .
git commit -m "PocketTrack v1"
git branch -M main
git remote add origin https://github.com/<you>/PocketTrack.git
git push -u origin main
```
Every push triggers `.github/workflows/android.yml`, which builds the debug APK.
Download it from the **Actions** tab → latest run → *PocketTrack-debug-apk*.
