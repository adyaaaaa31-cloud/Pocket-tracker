package com.pockettrack.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pockettrack.app.data.GoalEntity
import com.pockettrack.app.util.formatRupees
import kotlin.math.max

@Composable
fun GoalScreen(
    goal: GoalEntity?,
    balance: Double,
    onSave: (String, Double) -> Unit,
    onClear: () -> Unit
) {
    var editing by rememberSaveable { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Savings goal", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        if (goal == null || editing) {
            GoalForm(
                initialName = goal?.name ?: "",
                initialTarget = goal?.target,
                onSave = { n, t -> onSave(n, t); editing = false },
                onCancel = if (goal != null) ({ editing = false }) else null
            )
        } else {
            val saved = max(balance, 0.0)
            val fraction = (saved / goal.target).coerceIn(0.0, 1.0).toFloat()
            val reached = saved >= goal.target

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        goal.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        "${formatRupees(saved)} of ${formatRupees(goal.target)}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    LinearProgressIndicator(
                        progress = { fraction },
                        modifier = Modifier.fillMaxWidth().height(12.dp)
                    )
                    Text(
                        if (reached) "🎉 Goal reached!"
                        else "${(fraction * 100).toInt()}% done • ${formatRupees(goal.target - saved)} to go",
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Text(
                "Your remaining balance (money received minus expenses) counts as your savings.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { editing = true }) { Text("Edit goal") }
                TextButton(onClick = { confirmRemove = true }) { Text("Remove goal") }
            }
        }
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text("Remove savings goal?") },
            text = { Text("Your transactions are not affected.") },
            confirmButton = { TextButton(onClick = { onClear(); confirmRemove = false }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun GoalForm(
    initialName: String,
    initialTarget: Double?,
    onSave: (String, Double) -> Unit,
    onCancel: (() -> Unit)?
) {
    var name by rememberSaveable { mutableStateOf(initialName) }
    var targetText by rememberSaveable {
        mutableStateOf(
            when {
                initialTarget == null -> ""
                initialTarget % 1.0 == 0.0 -> initialTarget.toLong().toString()
                else -> initialTarget.toString()
            }
        )
    }
    var error by remember { mutableStateOf<String?>(null) }
    val regex = remember { Regex("^\\d{0,8}(\\.\\d{0,2})?$") }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            "What are you saving for? Set a target and watch your progress.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = name,
            onValueChange = { if (it.length <= 40) name = it },
            label = { Text("Goal name (e.g. New phone)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = targetText,
            onValueChange = { if (regex.matches(it)) { targetText = it; error = null } },
            label = { Text("Target amount") },
            prefix = { Text("₹") },
            isError = error != null,
            supportingText = error?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val target = targetText.toDoubleOrNull()
                if (target == null || target <= 0.0) {
                    error = "Enter a target greater than ₹0"
                } else {
                    onSave(name.ifBlank { "My savings goal" }, target)
                }
            }) { Text("Save goal") }
            if (onCancel != null) TextButton(onClick = onCancel) { Text("Cancel") }
        }
    }
}
