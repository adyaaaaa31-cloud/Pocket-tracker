package com.pockettrack.app.util

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

/** Formats like ₹1,23,456 or ₹1,234.50 (Indian digit grouping). */
fun formatRupees(amount: Double): String {
    val paise = Math.round(abs(amount) * 100)
    val rupees = paise / 100
    val fraction = (paise % 100).toInt()
    val digits = rupees.toString()
    val grouped = if (digits.length <= 3) {
        digits
    } else {
        val last3 = digits.takeLast(3)
        val rest = digits.dropLast(3)
        rest.reversed().chunked(2).joinToString(",").reversed() + "," + last3
    }
    val sign = if (amount < 0 && paise > 0) "-" else ""
    val frac = if (fraction == 0) "" else "." + fraction.toString().padStart(2, '0')
    return "$sign₹$grouped$frac"
}

private val dayFormat = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)
private val monthFormat = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)

fun formatDay(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(dayFormat)

fun formatMonth(month: YearMonth): String = month.format(monthFormat)
