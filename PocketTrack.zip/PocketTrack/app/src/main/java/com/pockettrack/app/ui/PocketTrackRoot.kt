package com.pockettrack.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pockettrack.app.data.MainViewModel
import com.pockettrack.app.data.summary
import java.time.LocalDate

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("dashboard", "Home", Icons.Filled.Home),
    Tab("history", "History", Icons.Filled.History),
    Tab("goal", "Goal", Icons.Filled.Savings),
    Tab("report", "Report", Icons.Filled.BarChart)
)

@Composable
fun PocketTrackRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val txs by vm.transactions.collectAsStateWithLifecycle()
    val goal by vm.goal.collectAsStateWithLifecycle()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val isTab = tabs.any { it.route == route }
    val balance = remember(txs) { txs.summary(LocalDate.now().toEpochDay()).balance }

    Scaffold(
        bottomBar = {
            if (isTab) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (route == "dashboard" || route == "history") {
                ExtendedFloatingActionButton(
                    onClick = { nav.navigate("add") },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Add") }
                )
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = "dashboard", modifier = Modifier.padding(padding)) {
            composable("dashboard") { DashboardScreen(txs) }
            composable("history") { HistoryScreen(txs, onDelete = vm::deleteTransaction) }
            composable("goal") {
                GoalScreen(goal, balance, onSave = vm::saveGoal, onClear = vm::clearGoal)
            }
            composable("report") { ReportScreen(txs) }
            composable("add") {
                AddTransactionScreen(
                    onSave = { type, amount, desc, cat, day ->
                        vm.addTransaction(type, amount, desc, cat, day)
                        nav.popBackStack()
                    },
                    onBack = { nav.popBackStack() }
                )
            }
        }
    }
}
