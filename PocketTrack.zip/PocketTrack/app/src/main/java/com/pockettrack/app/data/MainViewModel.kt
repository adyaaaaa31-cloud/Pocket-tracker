package com.pockettrack.app.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)

    val transactions: StateFlow<List<TransactionEntity>> = db.transactionDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val goal: StateFlow<GoalEntity?> = db.goalDao().observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun addTransaction(type: TxType, amount: Double, description: String, category: Category, epochDay: Long) {
        viewModelScope.launch {
            db.transactionDao().insert(
                TransactionEntity(
                    type = type.name,
                    amount = amount,
                    description = description.trim(),
                    category = category.name,
                    epochDay = epochDay
                )
            )
        }
    }

    fun deleteTransaction(t: TransactionEntity) {
        viewModelScope.launch { db.transactionDao().delete(t) }
    }

    fun saveGoal(name: String, target: Double) {
        viewModelScope.launch { db.goalDao().upsert(GoalEntity(1, name.trim(), target)) }
    }

    fun clearGoal() {
        viewModelScope.launch { db.goalDao().clear() }
    }
}
