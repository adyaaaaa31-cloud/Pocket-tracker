package com.pockettrack.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pockettrack.app.data.Category
import com.pockettrack.app.data.TransactionEntity
import com.pockettrack.app.data.TxType
import com.pockettrack.app.ui.theme.incomeColor
import com.pockettrack.app.util.formatMonth
import com.pockettrack.app.util.formatRupees
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun ReportScreen(txs: List<TransactionEntity>) {
    val now = remember { YearMonth.now() }
    val currentIndex = now.year * 12 + now.monthValue - 1
    var monthIndex by rememberSaveable { mutableStateOf(currentIndex) }
    val month = YearMonth.of(monthIndex / 12, monthIndex % 12 + 1)

    val inMonth = remember(txs, month) {
        txs.filter { YearMonth.from(LocalDate.ofEpochDay(it.epochDay)) == month }
    }
    val income = inMonth.filter { it.type == TxType.INCOME.name }.sumOf { it.amount }
    val expenses = inMonth.filter { it.type == TxType.EXPENSE.name }
    val expenseTotal = expenses.sumOf { it.amount }
    val byCategory = remember(inMonth) {
        expenses.groupBy { it.category }
            .map { (cat, list) -> Category.fromName(cat) to list.sumOf { it.amount } }
            .sortedByDescending { it.second }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Monthly report", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { monthIndex -= 1 }) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
            }
            Text(formatMonth(month), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { monthIndex += 1 }, enabled = monthIndex < currentIndex) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Income", formatRupees(income), incomeColor(), Modifier.weight(1f))
            StatCard("Expenses", formatRupees(expenseTotal), MaterialTheme.colorScheme.error, Modifier.weight(1f))
        }
        StatCard(
            "Net for the month",
            formatRupees(income - expenseTotal),
            if (income - expenseTotal >= 0) incomeColor() else MaterialTheme.colorScheme.error,
            Modifier.fillMaxWidth()
        )

        Text("Spending by category", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (byCategory.isEmpty()) {
            EmptyState("No expenses recorded in ${formatMonth(month)}.")
        } else {
            byCategory.forEach { (cat, total) ->
                val share = (total / expenseTotal).coerceIn(0.0, 1.0)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${cat.emoji} ${cat.label}", fontWeight = FontWeight.Medium)
                        Text("${formatRupees(total)} • ${(share * 100).toInt()}%")
                    }
                    LinearProgressIndicator(progress = { share.toFloat() }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
