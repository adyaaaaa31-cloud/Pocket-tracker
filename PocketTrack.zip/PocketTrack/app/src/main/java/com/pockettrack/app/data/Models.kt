package com.pockettrack.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TxType(val label: String) {
    INCOME("Income"),
    EXPENSE("Expense")
}

enum class Category(val label: String, val emoji: String) {
    FOOD("Food", "🍔"),
    TRAVEL("Travel", "🚌"),
    SHOPPING("Shopping", "🛍️"),
    EDUCATION("Education", "📚"),
    RECHARGE("Recharge", "📱"),
    ENTERTAINMENT("Entertainment", "🎬"),
    OTHER("Other", "🧾");

    companion object {
        fun fromName(name: String): Category = entries.firstOrNull { it.name == name } ?: OTHER
    }
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,          // TxType.name
    val amount: Double,        // rupees
    val description: String,
    val category: String,      // Category.name
    val epochDay: Long         // LocalDate.toEpochDay()
)

@Entity(tableName = "goal")
data class GoalEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val target: Double
)

data class Summary(val income: Double, val expense: Double, val today: Double) {
    val balance: Double get() = income - expense
}

fun List<TransactionEntity>.summary(todayEpochDay: Long): Summary {
    var income = 0.0
    var expense = 0.0
    var today = 0.0
    for (t in this) {
        if (t.type == TxType.INCOME.name) {
            income += t.amount
        } else {
            expense += t.amount
            if (t.epochDay == todayEpochDay) today += t.amount
        }
    }
    return Summary(income, expense, today)
}
