package com.pockettrack.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pockettrack.app.data.TransactionEntity
import com.pockettrack.app.data.TxType
import com.pockettrack.app.util.formatRupees

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(txs: List<TransactionEntity>, onDelete: (TransactionEntity) -> Unit) {
    var filter by rememberSaveable { mutableStateOf("ALL") }
    var newestFirst by rememberSaveable { mutableStateOf(true) }
    var pending by remember { mutableStateOf<TransactionEntity?>(null) }

    // `txs` already arrives newest-first from Room.
    val shown = remember(txs, filter, newestFirst) {
        val filtered = if (filter == "ALL") txs else txs.filter { it.type == filter }
        if (newestFirst) filtered else filtered.reversed()
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 16.dp)) {
        Text("History", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("All") })
            FilterChip(
                selected = filter == TxType.INCOME.name,
                onClick = { filter = TxType.INCOME.name },
                label = { Text("Income") }
            )
            FilterChip(
                selected = filter == TxType.EXPENSE.name,
                onClick = { filter = TxType.EXPENSE.name },
                label = { Text("Expenses") }
            )
        }
        AssistChip(
            modifier = Modifier.padding(top = 4.dp),
            onClick = { newestFirst = !newestFirst },
            label = { Text(if (newestFirst) "Date: newest first" else "Date: oldest first") }
        )

        if (shown.isEmpty()) {
            EmptyState(
                if (txs.isEmpty()) "No transactions yet." else "Nothing matches this filter.",
                Modifier.padding(top = 24.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier.padding(top = 8.dp),
                contentPadding = PaddingValues(bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { t ->
                    TransactionRow(t, onDelete = { pending = t })
                }
            }
        }
    }

    pending?.let { t ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Delete transaction?") },
            text = { Text("This ${formatRupees(t.amount)} entry will be permanently deleted.") },
            confirmButton = {
                TextButton(onClick = { onDelete(t); pending = null }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text("Cancel") }
            }
        )
    }
}
